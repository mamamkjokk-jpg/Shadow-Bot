const login  = require("ws3-fca").login;
const fs     = require("fs");
const path   = require("path");
const https  = require("https");
const http   = require("http");
const { downloadVideo, downloadAudio } = require("./lib/dl");

/* ── Keep-alive HTTP server on port 3001 ── */
http.createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end("Taya Bot is running ✅");
}).listen(3001, "0.0.0.0", () => {
    console.log("[BOT] Keep-alive server listening on port 3001");
});

const APPSTATE_FILE   = "./appstate.json";
const PREFIXES_FILE   = "./data/prefixes.json";
const PENDING_FILE    = "./data/restart_pending.json";
const PROTECTION_FILE = "./data/protection.json";
const LOCK_FILE       = "./data/lock.json";
const PID_FILE        = "./data/bot.pid";
const DEVELOPER_ID    = "61589645620146";
const WELCOME_GIF     = "https://i.imgur.com/bLDeWNU.gif";
const RECONNECT_DELAY = 5000;
const BOT_NICKNAME    = "〘❍Taya❍〙";
const SEL_TIMEOUT_MS  = 5 * 60 * 1000;

let botAvatarUrl = null;   /* bot profile picture / avatar */

const AUTO_DL_PATTERN = /https?:\/\/[^\s]+/i;

let config = require("./config.json");

const commands          = new Map();
let   threadPrefixes    = {};
const pendingSelections = new Map();
let   protectionData    = {};
const burnSessions      = new Map();
let   messageCount      = 0;
let   botLocked         = false;

/* ── Dedup ── */
const seenMessages = new Set();
function isDuplicate(mid) {
    if (!mid) return false;
    if (seenMessages.has(mid)) return true;
    seenMessages.add(mid);
    if (seenMessages.size > 500) seenMessages.delete(seenMessages.values().next().value);
    return false;
}

/* ── PID lock ── */
function acquireLock() {
    fs.mkdirSync("./data", { recursive: true });
    try {
        const old = parseInt(fs.readFileSync(PID_FILE, "utf8").trim(), 10);
        if (old && old !== process.pid) {
            try { process.kill(old, "SIGKILL"); } catch {}
            console.log(`[BOT] Killed previous instance (PID ${old})`);
        }
    } catch {}
    fs.writeFileSync(PID_FILE, String(process.pid));
}
function releaseLock() {
    try {
        if (parseInt(fs.readFileSync(PID_FILE, "utf8").trim(), 10) === process.pid)
            fs.unlinkSync(PID_FILE);
    } catch {}
}
process.on("exit",    releaseLock);
process.on("SIGTERM", () => { releaseLock(); process.exit(0); });
process.on("SIGINT",  () => { releaseLock(); process.exit(0); });

/* ── Prefixes ── */
function loadPrefixes() {
    try {
        if (fs.existsSync(PREFIXES_FILE))
            threadPrefixes = JSON.parse(fs.readFileSync(PREFIXES_FILE, "utf8"));
    } catch { threadPrefixes = {}; }
}
function savePrefix(threadID, p) {
    threadPrefixes[threadID] = p;
    fs.mkdirSync("./data", { recursive: true });
    fs.writeFileSync(PREFIXES_FILE, JSON.stringify(threadPrefixes, null, 2));
}
function removePrefix(threadID) {
    delete threadPrefixes[threadID];
    fs.mkdirSync("./data", { recursive: true });
    fs.writeFileSync(PREFIXES_FILE, JSON.stringify(threadPrefixes, null, 2));
}
function getPrefix(threadID) {
    return threadPrefixes[threadID] || config.prefix;
}

/* ── Protection ── */
function loadProtection() {
    try {
        if (fs.existsSync(PROTECTION_FILE))
            protectionData = JSON.parse(fs.readFileSync(PROTECTION_FILE, "utf8"));
    } catch { protectionData = {}; }
}
function saveProtection() {
    fs.mkdirSync("./data", { recursive: true });
    fs.writeFileSync(PROTECTION_FILE, JSON.stringify(protectionData, null, 2));
}
function getProtect(threadID) {
    if (!protectionData[threadID]) {
        protectionData[threadID] = {
            on: false, admin: true, nickname: true, name: true, lockJoin: false,
            savedNicknames: {}, savedName: "", admins: []
        };
    }
    return protectionData[threadID];
}

/* ── Bot Lock ── */
function loadLock() {
    try {
        if (fs.existsSync(LOCK_FILE))
            botLocked = JSON.parse(fs.readFileSync(LOCK_FILE, "utf8")).locked === true;
    } catch { botLocked = false; }
}
function setBotLocked(val) {
    botLocked = !!val;
    fs.mkdirSync("./data", { recursive: true });
    fs.writeFileSync(LOCK_FILE, JSON.stringify({ locked: botLocked }));
    console.log(`[BOT] Bot ${botLocked ? "LOCKED 🔒" : "UNLOCKED 🔓"}`);
}

/* ── Commands ── */
function loadCommands() {
    const dir = path.resolve("./commands");
    Object.keys(require.cache).forEach(k => { if (k.startsWith(dir)) delete require.cache[k]; });
    commands.clear();
    let files = [];
    try { files = fs.readdirSync("./commands").filter(f => f.endsWith(".js")); } catch {}
    for (const file of files) {
        try {
            const cmd = require(`./commands/${file}`);
            /* Mirai format: module.exports.config + module.exports.run */
            if (cmd.config && cmd.config.name && typeof cmd.run === "function") {
                const entry = { config: cmd.config, run: cmd.run };
                commands.set(cmd.config.name.toLowerCase(), entry);
                if (Array.isArray(cmd.config.aliases)) {
                    for (const alias of cmd.config.aliases) {
                        if (alias) commands.set(alias.toLowerCase(), entry);
                    }
                }
            }
        } catch (e) { console.error(`[ERROR] Load ${file}:`, e.message); }
    }
    console.log(`[BOT] Commands Loaded (Mirai): ${commands.size}`);
    return commands.size;
}

/* ── Helpers ── */
function fetchStream(url, hops) {
    hops = hops || 0;
    return new Promise((resolve, reject) => {
        if (hops > 5) return reject(new Error("Too many redirects"));
        const mod = url.startsWith("https") ? https : http;
        const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
                return fetchStream(res.headers.location, hops + 1).then(resolve).catch(reject);
            resolve(res);
        });
        req.on("error", reject);
        req.setTimeout(8000, () => { req.destroy(); reject(new Error("Timeout")); });
    });
}
function readAppState() {
    try {
        const raw = fs.readFileSync(APPSTATE_FILE, "utf8").trim();
        if (!raw || raw === "{}") return null;
        const p = JSON.parse(raw);
        return Array.isArray(p) && p.length ? p : null;
    } catch { return null; }
}
function saveAppState(api) {
    try { fs.writeFileSync(APPSTATE_FILE, JSON.stringify(api.getAppState(), null, 2)); } catch {}
}
function checkRestartPending(api) {
    try {
        if (!fs.existsSync(PENDING_FILE)) return;
        const data = JSON.parse(fs.readFileSync(PENDING_FILE, "utf8"));
        fs.unlinkSync(PENDING_FILE);
        if (data && data.threadID)
            setTimeout(() => api.sendMessage("Powered on ✅", data.threadID), 2000);
    } catch {}
}
function setNicknameIfNeeded(api, threadID) {
    const botID = String(api.getCurrentUserID());
    api.getThreadInfo(threadID, (err, info) => {
        if (err) return;
        const cur = ((info && info.nicknames) || {})[botID];
        if (!cur || !cur.trim())
            api.changeNickname(BOT_NICKNAME, threadID, botID, () => {});
    });
}

function fetchBotAvatar(api) {
    const botID = String(api.getCurrentUserID());
    api.getUserInfo([botID], (err, info) => {
        if (err || !info || !info[botID]) return;
        const pic = info[botID].thumbSrc || null;
        if (pic && pic.startsWith("http")) {
            botAvatarUrl = pic;
            console.log("[BOT] Avatar cached ✓");
        }
    });
}

/* ── Burn mode helpers ── */
function doAddKickCycle(api, threadID, userID, onDone) {
    api.addUserToGroup(userID, threadID, () => {
        setTimeout(() => {
            api.removeUserFromGroup(userID, threadID, () => {
                api.sendMessage("ادبل", threadID);
                setTimeout(onDone, 800);
            });
        }, 1500);
    });
}
function endBurnSession(api, threadID, key) {
    const s = burnSessions.get(key);
    if (!s || s.finished) return;
    s.finished = true;
    burnSessions.delete(key);
    api.sendMessage(
        "بيسسسس راحت كرامتهم حنيت عليهم بس إرادة اللورد المقدس 🪽 تكون اولى",
        threadID
    );
}

/* ── Pending selection download ── */
function handlePendingSelection(api, event, selKey, pending, num) {
    if (typeof pending.handler === "function") {
        pendingSelections.delete(selKey);
        return pending.handler(num, api, event);
    }

    const url   = pending.results[num - 1];
    const title = pending.titles[num - 1];

    api.setMessageReaction("🛸", event.messageID, () => {}, true);

    api.sendMessage(`⏳ جاري تحميل: ${title}`, event.threadID, (__, loadMsg) => {
        const loadMsgID = loadMsg && loadMsg.messageID;

        const cleanup = () => {
            if (loadMsgID) try { api.unsendMessage(loadMsgID, () => {}); } catch {}
        };

        const dl = pending.type === "audio" ? downloadAudio : downloadVideo;

        dl(url, (err, filePath) => {
            if (err) {
                cleanup();
                api.setMessageReaction("❌", event.messageID, () => {}, true);
                return api.sendMessage("❌ فشل التحميل!", event.threadID);
            }
            api.sendMessage(
                { body: `✅ ${title}`, attachment: fs.createReadStream(filePath) },
                event.threadID,
                (e) => {
                    cleanup();
                    try { fs.unlinkSync(filePath); } catch {}
                    if (e) {
                        api.setMessageReaction("❌", event.messageID, () => {}, true);
                        api.sendMessage("❌ فشل الإرسال، الملف ربما كبير!", event.threadID);
                    } else {
                        api.setMessageReaction("✅", event.messageID, () => {}, true);
                    }
                }
            );
        });
    });
}

/* ── Boot ── */
acquireLock();
loadPrefixes();
loadProtection();
loadLock();
loadCommands();

setInterval(() => {
    const now = Date.now();
    for (const [k, v] of pendingSelections) {
        if (now - v.timestamp > SEL_TIMEOUT_MS) pendingSelections.delete(k);
    }
}, 60000);

setInterval(() => {}, 1 << 30);

process.on("uncaughtException",  e => console.error("[UNCAUGHT]", e.message));
process.on("unhandledRejection", e => console.error("[UNHANDLED]", String(e)));

/* ── Listener ── */
function startListen(api) {
    console.log("[BOT] Starting listener...");
    const botID = String(api.getCurrentUserID());

    const stopListen = api.listenMqtt(async (err, event) => {
        if (err) {
            console.error("[MQTT] Disconnected:", err.error || err.message || err);
            try { stopListen(); } catch {}
            setTimeout(() => startListen(api), RECONNECT_DELAY);
            return;
        }

        if (event.senderID && String(event.senderID) === botID) return;
        if (isDuplicate(event.messageID)) return;

        /* ── Protection event handler ── */
        if (event.type === "event") {
            const prot  = getProtect(event.threadID);
            const actor = String(event.author || event.senderID || "");

            /* Lock join — remove newly added members */
            if (prot.on && prot.lockJoin &&
                event.logMessageType === "log:subscribe" &&
                event.logMessageData &&
                Array.isArray(event.logMessageData.addedParticipants)) {

                const added = event.logMessageData.addedParticipants;
                const botWasAdded = added.some(p => String(p.userFbId) === botID);

                if (botWasAdded) {
                    /* Bot joined — send welcome instead of removing */
                    const welcomeText = `دخلت ${config.botName} القروب اكتب Help`;
                    try {
                        const stream = await fetchStream(WELCOME_GIF);
                        api.sendMessage({ body: welcomeText, attachment: stream }, event.threadID);
                    } catch { api.sendMessage(welcomeText, event.threadID); }
                    setTimeout(() => setNicknameIfNeeded(api, event.threadID), 2000);
                } else {
                    /* Lock join — kick newly added */
                    for (const p of added) {
                        const uid = String(p.userFbId);
                        if (uid !== botID) {
                            api.removeUserFromGroup(uid, event.threadID, () => {});
                        }
                    }
                    api.sendMessage("🔒 Join is locked — new members removed.", event.threadID);
                }
            } else if (event.logMessageType === "log:subscribe" &&
                       event.logMessageData &&
                       Array.isArray(event.logMessageData.addedParticipants)) {

                const added       = event.logMessageData.addedParticipants;
                const botWasAdded = added.some(p => String(p.userFbId) === botID);
                const newUsers    = added.filter(p => String(p.userFbId) !== botID);
                const actorID     = String(event.author || event.senderID || "");

                if (botWasAdded) {
                    /* Check if developer is in the group — if not, send rude msg and leave */
                    api.getThreadInfo(event.threadID, (err, tInfo) => {
                        const members = (tInfo && tInfo.participantIDs || []).map(String);
                        const devInGroup = members.includes(DEVELOPER_ID);

                        if (!devInGroup) {
                            const rudeMsg = "انتو قح ؟ مطور مافيش هنا كحـ مـ!ـك!ـم انا طالع";
                            api.sendMessage(rudeMsg, event.threadID, () => {
                                api.removeUserFromGroup(botID, event.threadID, () => {});
                            });
                        } else {
                            /* Developer is here — send welcome */
                            const welcomeText = `دخلت ${config.botName} القروب اكتب Help`;
                            try {
                                fetchStream(WELCOME_GIF).then(stream => {
                                    api.sendMessage({ body: welcomeText, attachment: stream }, event.threadID);
                                }).catch(() => api.sendMessage(welcomeText, event.threadID));
                            } catch { api.sendMessage(welcomeText, event.threadID); }
                            setTimeout(() => setNicknameIfNeeded(api, event.threadID), 2000);
                        }
                    });
                }

                /* Welcome new human members with styled card */
                if (newUsers.length > 0) {
                    api.getThreadInfo(event.threadID, async (err, tInfo) => {
                        if (err || !tInfo) return;
                        const groupName   = tInfo.name || tInfo.threadName || "القروب";
                        const memberCount = (tInfo.participantIDs || []).length;
                        const groupID     = event.threadID;

                        /* Fetch adder name */
                        let adderName = "مجهول";
                        if (actorID) {
                            await new Promise(r => {
                                api.getUserInfo([actorID], (e, info) => {
                                    if (!e && info && info[actorID])
                                        adderName = info[actorID].name || adderName;
                                    r();
                                });
                            });
                        }

                        for (let i = 0; i < newUsers.length; i++) {
                            const p          = newUsers[i];
                            const joinerName = p.fullName || p.name || "العضو الجديد";
                            const rank       = memberCount - newUsers.length + i + 1;

                            const now   = new Date();
                            const date  = now.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
                            const clock = now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit", hour12: true });

                            const msg =
`˼🎉˹↜ ᴡᴇʟᴄᴏᴍᴇ ↶ ╮──────────────⟢
┆˼👤˹┊ الاسم    ↜｢ ${joinerName} ｣
┆˼➕˹┊ الضافه   ↜｢ ${adderName} ｣
├────────────────────────⟢
┆˼🏠˹┊ القروب   ↜｢ ${groupName} ｣
┆˼🆔˹┊ الأيدي   ↜｢ ${groupID} ｣
┆˼👥˹┊ الأعضاء  ↜｢ ${memberCount} عضو ｣
┆˼🔢˹┊ العضو رقم ↜｢ #${rank} ｣
├────────────────────────⟢
┆˼📅˹┊ التاريخ  ↜｢ ${date} ｣
┆˼⏰˹┊ الوقت    ↜｢ ${clock} ｣
╯──────────────⟢`;

                            api.sendMessage(msg, event.threadID);
                        }
                    });
                }
            }

            /* Admin protection — restore demoted admin & demote the actor */
            if (prot.on && prot.admin &&
                event.logMessageType === "log:thread-admins" &&
                event.logMessageData) {

                const adminEvent = event.logMessageData.ADMIN_EVENT || "";
                const targetIDs  = (event.logMessageData.TARGET_IDS || []).map(String);

                if (adminEvent === "remove_admin" && actor && actor !== botID) {
                    setTimeout(() => {
                        for (const tid of targetIDs) {
                            api.changeAdminStatus(event.threadID, [tid], true, () => {});
                        }
                        api.changeAdminStatus(event.threadID, [actor], false, () => {});
                        api.sendMessage(
                            `🛡️ Admin protected!\n👤 Removed from admin: ${actor}\n♻️ Restored: ${targetIDs.join(", ")}`,
                            event.threadID
                        );
                    }, 800);
                }
            }

            /* Nickname protection — restore saved nickname */
            if (prot.on && prot.nickname &&
                event.logMessageType === "log:user-nickname" &&
                event.logMessageData) {

                const uid   = String(event.logMessageData.participant_id || "");
                const saved = prot.savedNicknames && prot.savedNicknames[uid];
                if (uid && saved !== undefined) {
                    setTimeout(() => {
                        api.changeNickname(saved || "", event.threadID, uid, () => {});
                    }, 600);
                }
            }

            /* Group name protection — restore saved name */
            if (prot.on && prot.name &&
                event.logMessageType === "log:thread-name" &&
                prot.savedName) {

                setTimeout(() => {
                    api.setTitle(prot.savedName, event.threadID, () => {});
                }, 600);
            }
        }

        /* ── Burn mode reaction handler ── */
        if (event.type === "message_reaction") {
            const sessionKey = `${event.threadID}_${event.messageID}`;
            const session    = burnSessions.get(sessionKey);
            const reactorID  = String(event.senderID || event.userID || "");

            if (session && !session.finished && event.reaction === "❤️" &&
                reactorID && reactorID !== botID && reactorID !== DEVELOPER_ID) {

                session.count++;

                if (session.count >= 8) {
                    doAddKickCycle(api, event.threadID, reactorID, () => {
                        endBurnSession(api, event.threadID, sessionKey);
                    });
                } else {
                    doAddKickCycle(api, event.threadID, reactorID, () => {});
                }
            }
            return;
        }

        /* Allow both plain messages and reply messages */
        const isMessage      = event.type === "message";
        const isReplyMessage = event.type === "message_reply";
        if (!isMessage && !isReplyMessage) return;

        messageCount++;
        const body    = event.body || "";
        const prefix  = getPrefix(event.threadID);
        const lower   = body.trim().toLowerCase();
        const trimmed = body.trim();

        /* ── Reply-based pending selection (runs for both message & message_reply) ── */
        const senderID = String(event.senderID || event.author || "");
        const selKey   = `${event.threadID}_${senderID}`;
        const pending  = pendingSelections.get(selKey);
        if (pending) {
            const replyBody = (event.messageReply && event.messageReply.body) || "";
            const checkText = trimmed || replyBody;
            const western = checkText
                .replace(/[٠١٢٣٤٥٦٧٨٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d))
                .replace(/[０-９]/g, d => d.charCodeAt(0) - 0xFF10);
            const numMatch = western.match(/\d+/);
            const num = numMatch ? parseInt(numMatch[0], 10) : NaN;
            console.log(`[SEL] key=${selKey} type=${event.type} body="${trimmed}" num=${num} max=${pending.results.length}`);
            if (!isNaN(num) && num >= 1 && num <= pending.results.length) {
                pendingSelections.delete(selKey);
                handlePendingSelection(api, event, selKey, pending, num);
                return;
            }
        }

        /* ── ❤️ Developer heart reaction on every developer message ── */
        if (senderID === DEVELOPER_ID && event.messageID) {
            api.setMessageReaction("❤️", event.messageID, () => {}, true);
        }

        /* "تايا" or "Taya" ping — send profile picture + status */
        if (/^(تايا|taya)\.?$/i.test(trimmed)) {
            if (botAvatarUrl) {
                fetchStream(botAvatarUrl)
                    .then(stream => api.sendMessage(
                        { body: "Taya-Online.. ✅", attachment: stream },
                        event.threadID
                    ))
                    .catch(() => api.sendMessage("Taya-Online.. ✅", event.threadID));
            } else {
                api.sendMessage("Taya-Online.. ✅", event.threadID);
            }
            return;
        }

        /* "prefix" keyword without prefix sign */
        if (lower === "prefix") {
            const cmd = commands.get("prefix");
            if (cmd) cmd.run({
                api, event, args: [], commands, config, prefix,
                systemPrefix: config.prefix,
                threadPrefix: threadPrefixes[event.threadID] || null,
                savePrefix, removePrefix, getPrefix
            });
            return;
        }

        /* Prefix command */
        if (body.startsWith(prefix)) {
            const args    = body.slice(prefix.length).trim().split(/ +/);
            const cmdName = args.shift().toLowerCase();

            /* Prefix alone — تعليق ساخر */
            if (!cmdName) {
                api.sendMessage(`قول h,elp يـمـ ـعاق`, event.threadID);
                return;
            }

            const command = commands.get(cmdName);
            if (!command) return;

            /* If bot is locked, only allow developer to use lock/unlock command */
            const LOCK_CMDS = ["lock", "unlock", "قفل", "فتح"];
            if (botLocked && !LOCK_CMDS.includes(cmdName)) {
                if (String(event.senderID) !== DEVELOPER_ID) return;
            }

            try {
                command.run({
                    api, event, args, cmdName, commands, config, prefix,
                    systemPrefix: config.prefix,
                    threadPrefix: threadPrefixes[event.threadID] || null,
                    loadCommands, savePrefix, removePrefix, getPrefix,
                    pendingSelections, getProtect, saveProtection,
                    burnSessions, DEVELOPER_ID, messageCount,
                    botLocked, setBotLocked
                });
            } catch (e) { console.error(`[ERROR] "${cmdName}":`, e.message); }
            return;
        }

        /* Auto URL download */
        const urlMatch = body.match(AUTO_DL_PATTERN);
        if (urlMatch) {
            const dlCmd = commands.get("تحميل");
            if (dlCmd) dlCmd.run({ api, event, args: [urlMatch[0]], commands, config, prefix });
        }
    });
}

/* ── Login ── */
function startBot() {
    const appState = readAppState();
    if (!appState) { console.error("[ERROR] appstate.json is empty or invalid."); return; }

    console.log("[BOT] Logging in...");
    login(appState, {
        listenEvents:     true,
        selfListen:       false,
        updatePresence:   false,
        autoReconnect:    false,
        autoMarkDelivery: false
    }, (err, api) => {
        if (err) {
            console.error("[ERROR] Login failed:", err.error || err.message || String(err));
            setTimeout(startBot, RECONNECT_DELAY);
            return;
        }
        saveAppState(api);
        console.log(`[BOT] ${config.botName} is ONLINE ✓`);
        checkRestartPending(api);
        fetchBotAvatar(api);
        startListen(api);
    });
}

startBot();
