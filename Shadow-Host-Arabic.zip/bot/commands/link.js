const axios    = require("axios");
const fs       = require("fs-extra");
const path     = require("path");
const https    = require("https");
const http     = require("http");
const FormData = require("form-data");

const CACHE = path.join(process.cwd(), "cache");

function fetchStream(url, hops) {
    hops = hops || 0;
    return new Promise((resolve, reject) => {
        if (hops > 5) return reject(new Error("Too many redirects"));
        const mod = url.startsWith("https") ? https : http;
        const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
                return fetchStream(res.headers.location, hops + 1).then(resolve).catch(reject);
            resolve(res);
        });
        req.on("error", reject);
        req.setTimeout(15000, () => { req.destroy(); reject(new Error("Timeout")); });
    });
}

async function uploadToCatbox(filePath) {
    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", fs.createReadStream(filePath));
    const res = await axios.post("https://catbox.moe/user.php", form, {
        headers: form.getHeaders(),
        timeout: 60000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity
    });
    if (typeof res.data === "string" && res.data.startsWith("https://")) return res.data.trim();
    throw new Error("catbox failed: " + res.data);
}

async function uploadToImgur(filePath) {
    const form = new FormData();
    form.append("image", fs.createReadStream(filePath));
    const res = await axios.post("https://api.imgur.com/3/image", form, {
        headers: { ...form.getHeaders(), Authorization: "Client-ID 546c25a59c58ad7" },
        timeout: 60000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity
    });
    if (res.data && res.data.data && res.data.data.link) return res.data.data.link;
    throw new Error("imgur failed");
}

function getAttachment(event) {
    const types = ["photo", "animated_image", "sticker", "file", "video"];

    /* صورة مرفقة مع الأمر */
    const own = (event.attachments || []).find(a => types.includes(a.type));
    if (own) return own;

    /* ردّ على رسالة */
    const replied = event.messageReply || event.reply;
    if (replied) {
        const replyAtt = (replied.attachments || []).find(a => types.includes(a.type));
        if (replyAtt) return replyAtt;
    }

    return null;
}

module.exports.config = {
    name: "link",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "ارفع صورة أو GIF واحصل على رابط مباشر",
    commandCategory: "ᴍᴇᴅɪᴀ",
    usages: "link — أرسل مع صورة/GIF أو ردّ على صورة",
    cooldowns: 5,
    aliases: ["رفع", "upload"]
};

module.exports.run = async function({ api, event }) {
    const tid = event.threadID;

    const att = getAttachment(event);
    if (!att) {
        return api.sendMessage(
            "❌ أرسل الأمر مع صورة أو GIF، أو ردّ على رسالة تحتوي على صورة/GIF",
            tid
        );
    }

    /* جرّب جميع حقول الرابط الموجودة في الـ attachment */
    const fileUrl = att.playbackUrl || att.previewUrl || att.url ||
                    att.largePreviewUrl || att.thumbnailUrl || att.source;

    if (!fileUrl) {
        return api.sendMessage("❌ تعذّر الحصول على رابط الملف!", tid);
    }

    const loadMsg = await new Promise(r =>
        api.sendMessage("Loading... Please wait... 📥", tid, (__, m) => r(m))
    );
    const loadID = loadMsg && loadMsg.messageID;
    const cleanup = () => { if (loadID) try { api.unsendMessage(loadID, () => {}); } catch {} };

    try {
        await fs.ensureDir(CACHE);

        const ext = att.type === "animated_image" ? "gif"
                  : att.type === "video"          ? "mp4"
                  : "jpg";
        const tempPath = path.join(CACHE, `link_${Date.now()}.${ext}`);

        const stream = await fetchStream(fileUrl);
        const writer = fs.createWriteStream(tempPath);
        stream.pipe(writer);
        await new Promise((res, rej) => { writer.on("finish", res); writer.on("error", rej); });

        let uploadedUrl = null;
        try { uploadedUrl = await uploadToCatbox(tempPath); } catch {}
        if (!uploadedUrl) { try { uploadedUrl = await uploadToImgur(tempPath); } catch {} }

        fs.remove(tempPath).catch(() => {});
        cleanup();

        if (!uploadedUrl) return api.sendMessage("❌ فشل الرفع على جميع المواقع!", tid);

        api.sendMessage(
`╭────────────────────⟢
┆ ˼🔗˹ تم الرفع بنجاح
├────────────────────⟢
┆ ${uploadedUrl}
╰────────────────────⟢`,
            tid
        );
    } catch {
        cleanup();
        api.sendMessage("❌ حدث خطأ أثناء الرفع!", tid);
    }
};
