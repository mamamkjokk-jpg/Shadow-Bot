const axios  = require("axios");
const fs     = require("fs-extra");
const path   = require("path");
const { exec } = require("child_process");
const os     = require("os");

const CACHE     = path.join(process.cwd(), "cache");
const YTDLP     = "/home/runner/workspace/.pythonlibs/bin/yt-dlp";
const YT_API    = "https://neokex-dlapis.vercel.app/api/search?q=";
const YT_DL_API = "https://neokex-dlapis.vercel.app/api/alldl?url=";
const TT_API    = "https://lyric-search-neon.vercel.app/kshitiz?keyword=";

const TIMEOUT = 45000;

function withTimeout(promise, ms) {
    return Promise.race([
        promise,
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), ms))
    ]);
}

function ytdlpDownload(url) {
    return new Promise((resolve, reject) => {
        const uid  = `edit_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
        const tmpl = path.join(os.tmpdir(), `${uid}.%(ext)s`);
        const cmd  = `${YTDLP} -o "${tmpl}" --format "bv*[ext=mp4]+ba[ext=m4a]/best[ext=mp4]/best" --merge-output-format mp4 --max-filesize 50m --no-playlist "${url}" 2>&1`;
        exec(cmd, { timeout: 120000 }, (err, stdout) => {
            if (err) return reject(new Error("ytdlp_failed: " + (stdout || err.message).slice(0, 100)));
            const files = fs.readdirSync(os.tmpdir()).filter(n => n.startsWith(uid));
            if (!files.length) return reject(new Error("file_not_found"));
            resolve(path.join(os.tmpdir(), files[0]));
        });
    });
}

async function downloadFromUrl(url) {
    const filePath = path.join(CACHE, `edit_${Date.now()}.mp4`);
    const res = await axios({ url, method: "GET", responseType: "stream", timeout: 60000 });
    const writer = fs.createWriteStream(filePath);
    res.data.pipe(writer);
    await new Promise((r, rej) => { writer.on("finish", r); writer.on("error", rej); });
    return filePath;
}

async function tryYouTube(name) {
    const res = await axios.get(
        `${YT_API}${encodeURIComponent(name + " edit amv")}`,
        { timeout: 10000 }
    );
    const results = (res.data.results || []).slice(0, 8);
    if (!results.length) throw new Error("no_yt_results");

    for (let attempt = 0; attempt < 3; attempt++) {
        const pick = results[Math.floor(Math.random() * results.length)];
        try {
            const dlRes = await axios.get(
                `${YT_DL_API}${encodeURIComponent(pick.url)}`,
                { timeout: 12000 }
            );
            const pollUrl = dlRes.data.video && dlRes.data.video.downloadUrl;
            if (!pollUrl) continue;

            let streamUrl = null;
            for (let i = 0; i < 20; i++) {
                const st = await axios.get(pollUrl, { timeout: 8000 });
                if (st.data.status === "completed") { streamUrl = st.data.viewUrl; break; }
                if (st.data.status === "failed") break;
                await new Promise(r => setTimeout(r, 1500));
            }
            if (!streamUrl) continue;

            const filePath = await downloadFromUrl(streamUrl);
            return { filePath, title: pick.title, source: "YouTube" };
        } catch { continue; }
    }
    throw new Error("yt_all_attempts_failed");
}

async function tryTikTok(name) {
    const res = await axios.get(
        `${TT_API}${encodeURIComponent(name + " edit")}`,
        { timeout: 10000 }
    );
    const results = (res.data || []).filter(v => v.videoUrl).slice(0, 8);
    if (!results.length) throw new Error("no_tt_results");

    for (let attempt = 0; attempt < 3; attempt++) {
        const pick = results[Math.floor(Math.random() * results.length)];
        try {
            const filePath = await downloadFromUrl(pick.videoUrl);
            const title    = (pick.title || "").substring(0, 80);
            const author   = (pick.author && pick.author.unique_id) || "TikTok";
            return { filePath, title, author, source: "TikTok" };
        } catch { continue; }
    }
    throw new Error("tt_all_attempts_failed");
}

module.exports.config = {
    name: "edit",
    version: "4.0.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "Random character edit video from YouTube or TikTok",
    commandCategory: "𝗙𝗨𝗡",
    usages: "edit <character name>",
    cooldowns: 10,
    aliases: ["إديت", "ed"]
};

module.exports.run = async function ({ api, event, args }) {

    const tid  = event.threadID;
    const name = args.join(" ").trim();

    if (!name) {
        return api.sendMessage(
            "Write a character name\nExample: edit naruto",
            tid
        );
    }

    api.setMessageReaction("⏳", event.messageID, () => {}, true);

    try {
        await fs.ensureDir(CACHE);

        /* Try both sources, prefer whichever responds first */
        const useYT = Math.random() < 0.5;

        let result = null;

        if (useYT) {
            try {
                result = await withTimeout(tryYouTube(name), TIMEOUT);
            } catch (e) {
                console.log("[EDIT] YouTube failed:", e.message, "→ trying TikTok");
                result = await withTimeout(tryTikTok(name), TIMEOUT);
            }
        } else {
            try {
                result = await withTimeout(tryTikTok(name), TIMEOUT);
            } catch (e) {
                console.log("[EDIT] TikTok failed:", e.message, "→ trying YouTube");
                result = await withTimeout(tryYouTube(name), TIMEOUT);
            }
        }

        const body = result.source === "TikTok"
            ? `🎬 ${name} edit • TikTok\n━━━━━━━━━━━━━━\n${result.title}\n@${result.author}`
            : `🎬 ${name} edit • YouTube\n━━━━━━━━━━━━━━\n${result.title}`;

        api.setMessageReaction("✅", event.messageID, () => {}, true);
        return api.sendMessage(
            { body, attachment: fs.createReadStream(result.filePath) },
            tid,
            () => { fs.remove(result.filePath).catch(() => {}); }
        );

    } catch (err) {
        console.log("[EDIT] All sources failed:", err.message);
        api.setMessageReaction("❌", event.messageID, () => {}, true);
        return api.sendMessage(
            `❌ Couldn't find an edit for "${name}", try again!`,
            tid
        );
    }
};
