"use strict";
const { execSync } = require("child_process");
const os           = require("os");

module.exports.config = {
    name: "uptime",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "Bot uptime & system stats",
    commandCategory: "sʏsᴛᴇᴍ",
    usages: "uptime",
    cooldowns: 5,
    aliases: ["upt", "ابتايم"]
};

module.exports.run = async function({ api, event, commands, messageCount }) {
    const ping = Date.now();
    const tid  = event.threadID;

    const uptimeSec = Math.floor(process.uptime());
    const d  = Math.floor(uptimeSec / 86400);
    const h  = Math.floor((uptimeSec % 86400) / 3600);
    const m  = Math.floor((uptimeSec % 3600)  / 60);
    const sc = uptimeSec % 60;
    const uptimeStr = `${d}d ${h}h ${m}m ${sc}s`;

    const total   = os.totalmem();
    const free    = os.freemem();
    const usedMB  = ((total - free) / 1024 / 1024).toFixed(0);
    const totalMB = (total / 1024 / 1024).toFixed(0);
    const cpuLoad = Math.min(99, ((os.loadavg()[0] / os.cpus().length) * 100)).toFixed(1);
    const hostname = os.hostname();
    const platform = os.platform();
    const arch     = os.arch();
    const nodeVer  = process.version;
    const cmdCount = commands ? commands.size : 0;
    const pulses   = messageCount || 0;

    let diskStr = "N/A";
    try {
        const out    = execSync("df / | tail -1").toString().trim().split(/\s+/);
        const used   = parseInt(out[2]);
        const total2 = parseInt(out[1]);
        const pct    = Math.round((used / total2) * 100);
        const toGB   = v => (v / 1024 / 1024).toFixed(1);
        diskStr      = `${toGB(used)}GB / ${toGB(total2)}GB (${pct}%)`;
    } catch {}

    let hostingName = "Replit";
    try {
        if (process.env.REPL_SLUG || process.env.REPLIT_DB_URL) hostingName = "Replit ☁️";
        else if (process.env.HEROKU_APP_NAME) hostingName = "Heroku";
        else if (process.env.RAILWAY_ENVIRONMENT) hostingName = "Railway";
        else if (process.env.RENDER) hostingName = "Render";
        else if (process.env.FLY_APP_NAME) hostingName = "Fly.io";
        else hostingName = hostname;
    } catch {}

    api.sendMessage(`Loading status...🌐`, tid, (__, loadMsg) => {
        const loadID = loadMsg && loadMsg.messageID;
        const ms = Date.now() - ping;

        const msg =
`╭────────────────────⟢
┆ ˼⚡˹ TAYA — STATUS
├────────────────────⟢
┆˼⏱˹  Uptime   ↜ ${uptimeStr}
┆˼📶˹  Ping     ↜ ${ms} ms
┆˼🌐˹  Hosting  ↜ ${hostingName}
┆˼🖥˹  Server   ↜ ${hostname}
┆˼💓˹  Pulses   ↜ ${pulses}
┆˼🧩˹  Commands ↜ ${cmdCount}
├────────────────────⟢
┆˼💾˹  Memory   ↜ ${usedMB} / ${totalMB} MB
┆˼⚡˹  CPU      ↜ ${cpuLoad}%
┆˼🗄˹  Disk     ↜ ${diskStr}
┆˼📦˹  Node     ↜ ${nodeVer}
┆˼🐧˹  OS       ↜ ${platform} / ${arch}
╰────────────────────⟢`;

        if (loadID) {
            api.editMessage(msg, loadID, (editErr) => {
                if (editErr) {
                    api.unsendMessage(loadID, () => api.sendMessage(msg, tid));
                }
            });
        } else {
            api.sendMessage(msg, tid);
        }
    });
};
