const axios = require("axios");
const fs    = require("fs-extra");
const path  = require("path");
const https = require("https");
const http  = require("http");

const SEARCH_API = "https://lyric-search-neon.vercel.app/kshitiz?keyword=";
const CACHE      = path.join(process.cwd(), "cache");

function fetchStream(url, hops) {
    hops = hops || 0;
    return new Promise((resolve, reject) => {
        if (hops > 5) return reject(new Error("Too many redirects"));
        const mod = url.startsWith("https") ? https : http;
        const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
                return fetchStream(res.headers.location, hops + 1).then(resolve).catch(reject);
            resolve(res);
        });
        req.on("error", reject);
        req.setTimeout(8000, () => { req.destroy(); reject(new Error("Timeout")); });
    });
}

module.exports.config = {
    name: "tiktok",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "Search and download TikTok videos",
    commandCategory: "ᴍᴇᴅɪᴀ",
    usages: "tiktok <query>",
    cooldowns: 5,
    aliases: ["tt", "tik"]
};

module.exports.run = async function({ api, event, args, pendingSelections }) {
    const tid    = event.threadID;
    const query  = args.join(" ");
    const selKey = `${tid}_${event.senderID}`;

    if (!query)
        return api.sendMessage("❌ اكتب كلمة البحث!", tid);

    api.sendMessage("Loading... Please wait... 📥", tid, async (__, loadMsg) => {
        const loadID = loadMsg && loadMsg.messageID;

        try {
            const res     = await axios.get(`${SEARCH_API}${encodeURIComponent(query)}`, { timeout: 10000 });
            const results = (res.data || []).slice(0, 6);

            if (!results.length) {
                if (loadID) api.unsendMessage(loadID);
                return api.sendMessage("❌ لم يتم العثور على فيديوهات!", tid);
            }

            await fs.ensureDir(CACHE);

            let msg = `╭────────────────────⟢\n┆ ˼🎵˹ نتائج TikTok\n├────────────────────⟢\n`;
            for (let i = 0; i < results.length; i++) {
                const v = results[i];
                msg += `┆ ${i + 1}. ${(v.title || "").substring(0, 60)}\n┆    @${(v.author && v.author.unique_id) || "?"} • ${v.duration || "?"}s\n`;
            }
            msg += `├────────────────────⟢\n┆ ردّ برقم للتحميل 1-${results.length}\n╰────────────────────⟢`;

            if (loadID) api.unsendMessage(loadID);

            /* Attach thumbnail/cover of the first result */
            let thumbStream = null;
            const firstCover = results[0] && (results[0].cover || results[0].thumbnail || results[0].origin_cover);
            if (firstCover) {
                try { thumbStream = await fetchStream(firstCover); } catch {}
            }

            const sendOpts = thumbStream
                ? { body: msg, attachment: thumbStream }
                : { body: msg };

            api.sendMessage(sendOpts, tid, (__, listMsg) => {
                const listMsgID = listMsg && listMsg.messageID;

                pendingSelections.set(selKey, {
                    results: results.map(r => r.videoUrl || ""),
                    titles:  results.map(r => r.title || "TikTok"),
                    handler: async (num, api, ev) => {
                        if (listMsgID) try { api.unsendMessage(listMsgID); } catch {}

                        const sel = results[num - 1];
                        if (!sel || !sel.videoUrl) return api.sendMessage("❌ لا يوجد رابط تحميل!", ev.threadID);

                        api.setMessageReaction("⏳", ev.messageID, () => {}, true);
                        api.sendMessage("Loading... Please wait... 📥", ev.threadID, async (__, dlMsg) => {
                            const dlID    = dlMsg && dlMsg.messageID;
                            const filePath = path.join(CACHE, `tt_${Date.now()}.mp4`);
                            try {
                                const res = await axios({ url: sel.videoUrl, method: "GET", responseType: "stream", timeout: 60000 });
                                const writer = fs.createWriteStream(filePath);
                                res.data.pipe(writer);
                                await new Promise((r, rej) => { writer.on("finish", r); writer.on("error", rej); });

                                if (dlID) api.unsendMessage(dlID);
                                api.sendMessage(
                                    {
                                        body: `✅ ${sel.title}\n@${(sel.author && sel.author.unique_id) || "?"} • ${sel.duration || "?"}s`,
                                        attachment: fs.createReadStream(filePath)
                                    },
                                    ev.threadID,
                                    () => { fs.remove(filePath).catch(() => {}); }
                                );
                                api.setMessageReaction("✅", ev.messageID, () => {}, true);
                            } catch {
                                if (dlID) api.unsendMessage(dlID);
                                fs.remove(filePath).catch(() => {});
                                api.setMessageReaction("❌", ev.messageID, () => {}, true);
                                api.sendMessage("❌ فشل تحميل الفيديو!", ev.threadID);
                            }
                        });
                    }
                });

                setTimeout(() => pendingSelections.delete(selKey), 5 * 60 * 1000);
            });

        } catch {
            if (loadID) api.unsendMessage(loadID);
            api.sendMessage("❌ خطأ في البحث!", tid);
        }
    });
};
