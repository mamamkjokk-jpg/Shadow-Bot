const fs = require("fs");

const PENDING_FILE = "./data/restart_pending.json";

module.exports.config = {
    name: "reload",
    version: "1.0.0",
    hasPermssion: 1,
    credits: "Shadow",
    description: "إعادة تشغيل البوت",
    commandCategory: "sᴇᴛᴛɪɴɢs",
    usages: "reload",
    cooldowns: 10,
    aliases: []
};

module.exports.run = async function({ api, event }) {
    api.sendMessage("Rebooting... 📡", event.threadID, (err, info) => {
        const msgID = info && info.messageID;

        setTimeout(() => {
            if (msgID) {
                try { api.editMessage("Come closer... 🛸", msgID, () => {}); } catch {}
            }

            fs.mkdirSync("./data", { recursive: true });
            fs.writeFileSync(PENDING_FILE, JSON.stringify({ threadID: event.threadID }));

            setTimeout(() => process.exit(0), 800);
        }, 2000);
    });
};
