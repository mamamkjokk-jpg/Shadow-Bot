const axios = require("axios");
const fs    = require("fs-extra");
const path  = require("path");
const https = require("https");
const http  = require("http");

const CACHE = path.join(process.cwd(), "cache");

function getYtThumbnail(url) {
    const m = (url || "").match(/(?:youtu\.be\/|[?&]v=)([A-Za-z0-9_-]{11})/);
    return m ? `https://img.youtube.com/vi/${m[1]}/hqdefault.jpg` : null;
}

function fetchStream(url, hops) {
    hops = hops || 0;
    return new Promise((resolve, reject) => {
        if (hops > 5) return reject(new Error("Too many redirects"));
        const mod = url.startsWith("https") ? https : http;
        const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
                return fetchStream(res.headers.location, hops + 1).then(resolve).catch(reject);
            resolve(res);
        });
        req.on("error", reject);
        req.setTimeout(8000, () => { req.destroy(); reject(new Error("Timeout")); });
    });
}

module.exports.config = {
    name: "sing",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "Search and download YouTube audio",
    commandCategory: "ᴍᴇᴅɪᴀ",
    usages: "sing <اسم الأغنية>",
    cooldowns: 5,
    aliases: ["song", "music"]
};

module.exports.run = async function({ api, event, args, pendingSelections }) {
    const tid    = event.threadID;
    const query  = args.join(" ");
    const selKey = `${tid}_${event.senderID}`;

    if (!query)
        return api.sendMessage("❌ اكتب اسم الأغنية!", tid);

    api.sendMessage("Loading... Please wait... 📥", tid, async (__, loadMsg) => {
        const loadID = loadMsg && loadMsg.messageID;

        try {
            const res     = await axios.get(`https://neokex-dlapis.vercel.app/api/search?q=${encodeURIComponent(query)}`, { timeout: 10000 });
            const results = (res.data.results || []).slice(0, 6);

            if (!results.length) {
                if (loadID) api.unsendMessage(loadID);
                return api.sendMessage("❌ لم يتم العثور على نتائج!", tid);
            }

            await fs.ensureDir(CACHE);

            let msg = `╭────────────────────⟢\n┆ ˼🎵˹ نتائج الأغاني\n├────────────────────⟢\n`;
            for (let i = 0; i < results.length; i++) {
                msg += `┆ ${i + 1}. ${results[i].title}\n┆    [${results[i].duration || "—"}]\n`;
            }
            msg += `├────────────────────⟢\n┆ ردّ برقم للتحميل 1-${results.length}\n╰────────────────────⟢`;

            if (loadID) api.unsendMessage(loadID);

            /* Attach thumbnail of the first result */
            let thumbStream = null;
            const thumbUrl = getYtThumbnail(results[0] && results[0].url);
            if (thumbUrl) {
                try { thumbStream = await fetchStream(thumbUrl); } catch {}
            }

            const sendOpts = thumbStream
                ? { body: msg, attachment: thumbStream }
                : { body: msg };

            api.sendMessage(sendOpts, tid, (__, listMsg) => {
                const listMsgID = listMsg && listMsg.messageID;

                pendingSelections.set(selKey, {
                    results: results.map(r => r.url),
                    titles:  results.map(r => r.title),
                    handler: async (num, api, ev) => {
                        if (listMsgID) try { api.unsendMessage(listMsgID); } catch {}

                        const sel = results[num - 1];
                        if (!sel) return;
                        api.setMessageReaction("⏳", ev.messageID, () => {}, true);
                        api.sendMessage("Loading... Please wait... 📥", ev.threadID, async (__, dlMsg) => {
                            const dlID = dlMsg && dlMsg.messageID;
                            try {
                                const dlRes   = await axios.get(`https://neokex-dlapis.vercel.app/api/alldl?url=${encodeURIComponent(sel.url)}`, { timeout: 12000 });
                                const pollUrl = dlRes.data.audio && dlRes.data.audio.downloadUrl;
                                if (!pollUrl) throw new Error("no_url");

                                let streamUrl = null;
                                for (let i = 0; i < 25; i++) {
                                    const st = await axios.get(pollUrl, { timeout: 8000 });
                                    if (st.data.status === "completed") { streamUrl = st.data.viewUrl; break; }
                                    if (st.data.status === "failed") break;
                                    await new Promise(r => setTimeout(r, 500));
                                }
                                if (!streamUrl) throw new Error("timeout");

                                const filePath = path.join(CACHE, `${Date.now()}.mp3`);
                                const fileRes  = await axios.get(streamUrl, { responseType: "arraybuffer", timeout: 60000 });
                                await fs.writeFile(filePath, Buffer.from(fileRes.data));

                                if (dlID) api.unsendMessage(dlID);
                                api.sendMessage(
                                    { body: `✅ ${sel.title}`, attachment: fs.createReadStream(filePath) },
                                    ev.threadID,
                                    () => { fs.remove(filePath).catch(() => {}); }
                                );
                                api.setMessageReaction("✅", ev.messageID, () => {}, true);
                            } catch {
                                if (dlID) api.unsendMessage(dlID);
                                api.setMessageReaction("❌", ev.messageID, () => {}, true);
                                api.sendMessage("❌ فشل التحميل!", ev.threadID);
                            }
                        });
                    }
                });

                setTimeout(() => pendingSelections.delete(selKey), 5 * 60 * 1000);
            });

        } catch {
            if (loadID) api.unsendMessage(loadID);
            api.sendMessage("❌ خطأ في البحث!", tid);
        }
    });
};
