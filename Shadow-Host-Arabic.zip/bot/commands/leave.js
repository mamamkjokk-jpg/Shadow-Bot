const DEVELOPER_ID = "61589645620146";

module.exports.config = {
    name: "leave",
    version: "1.1.0",
    hasPermssion: 2,
    credits: "Shadow",
    description: "يطلع البوت من القروب",
    commandCategory: "ʙᴏᴛ",
    usages: "leave",
    cooldowns: 5,
    aliases: ["طلع", "اطلع"]
};

module.exports.run = async function({ api, event, DEVELOPER_ID: DEV_ID }) {
    const tid      = event.threadID;
    const senderID = String(event.senderID || "");
    const devID    = DEV_ID || DEVELOPER_ID;

    api.getThreadInfo(tid, (err, info) => {
        const adminIDs = ((info && info.adminIDs) || []).map(a => String(a.id || a));
        const isAdmin  = adminIDs.includes(senderID);
        const isDev    = senderID === devID;

        if (!isDev && !isAdmin) {
            return api.sendMessage("🚫 هذا الأمر للمطور والمشرفين فقط!", tid);
        }

        const leaveMsg = "احشكم و احش الضافني كلكم لوايتة 🖕\nساي لو دايرين امشو بيعو كرامتكم عند ابوي في الخاص";
        api.sendMessage(leaveMsg, tid, () => {
            api.removeUserFromGroup(String(api.getCurrentUserID()), tid, () => {});
        });
    });
};
