const https = require("https");
const http  = require("http");

function fetchStream(url, hops) {
    hops = hops || 0;
    return new Promise((resolve, reject) => {
        if (hops > 5) return reject(new Error("Too many redirects"));
        const mod = url.startsWith("https") ? https : http;
        const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
                return fetchStream(res.headers.location, hops + 1).then(resolve).catch(reject);
            resolve(res);
        });
        req.on("error", reject);
        req.setTimeout(8000, () => { req.destroy(); reject(new Error("Timeout")); });
    });
}

module.exports.config = {
    name: "developer",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "Bot & developer info",
    commandCategory: "ʙᴏᴛ",
    usages: "developer",
    cooldowns: 5,
    aliases: ["dev", "مطور"]
};

module.exports.run = async function({ api, event }) {
    const tid = event.threadID;
    const caption =
`╭────────────────────⟢
┆ ˼🤖˹ TAYA — BOT INFO
├────────────────────⟢
┆˼📛˹ Name     ↜ Taya
┆˼🌐˹ Type     ↜ Mirai Bot
┆˼♀˹  Gender   ↜ Feminine
├────────────────────⟢
┆ ˼👨‍💻˹ DEVELOPER INFO
├────────────────────⟢
┆˼🔑˹ Name     ↜ Shadow
┆˼🔢˹ Age      ↜ 17
┆˼🌍˹ Country  ↜ 🇸🇩 Sudan · 🇩🇿 Algeria
┆˼✈️˹  Telegram ↜ @iguviji
├────────────────────⟢
┆˼🛸˹ Taya was crafted
┆    to be your smartest
┆    companion in any
┆    group — always 🔛
╰────────────────────⟢`;

    try {
        const stream = await fetchStream("https://i.imgur.com/FHdGL05.jpeg");
        api.sendMessage({ body: caption, attachment: stream }, tid);
    } catch {
        api.sendMessage(caption, tid);
    }
};
