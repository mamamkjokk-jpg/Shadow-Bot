const https = require("https");
const http  = require("http");

const HELP_GIF = "https://i.imgur.com/YRPOtIc.gif";

function fetchStream(url, hops) {
    hops = hops || 0;
    return new Promise((resolve, reject) => {
        if (hops > 5) return reject(new Error("Too many redirects"));
        const mod = url.startsWith("https") ? https : http;
        const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
                return fetchStream(res.headers.location, hops + 1).then(resolve).catch(reject);
            resolve(res);
        });
        req.on("error", reject);
        req.setTimeout(10000, () => { req.destroy(); reject(new Error("Timeout")); });
    });
}

module.exports.config = {
    name: "help",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "عرض جميع الأوامر",
    commandCategory: "ʙᴏᴛ",
    usages: "help",
    cooldowns: 3,
    aliases: ["قائمة", "list", "cmds"]
};

module.exports.run = async function({ api, event, commands, prefix, config }) {
    const now   = new Date();
    const date  = now.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
    const time  = now.toTimeString().slice(0, 8);
    const days  = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    const day   = days[now.getDay()];
    const clock = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });

    const sections = {};
    const seen = new Set();
    for (const cmd of commands.values()) {
        if (!cmd.config) continue;
        if (cmd.config.hidden) continue;
        if (seen.has(cmd.config.name)) continue;
        seen.add(cmd.config.name);
        const cat = cmd.config.commandCategory || "ᴏᴛʜᴇʀ";
        if (!sections[cat]) sections[cat] = [];
        sections[cat].push(cmd.config.name);
    }

    const catKeys = Object.keys(sections);
    const lines   = [];

    catKeys.forEach((cat, i) => {
        lines.push(`✦┊ ⟬ ${cat} ⟭`);
        sections[cat].forEach(name => lines.push(`✦┊  · ${name}`));
        if (i < catKeys.length - 1) lines.push(`✦┊ ─────────────`);
    });

    const botName = (config && config.botName) || "Taya";

    const msg =
`˼⌛˹↜ ᴛɪᴍᴇ ↶ ╮──────────────⟢
┆˼🜲˹┊ ↜｢ ${date} ｣
┆˼✦˹┊ ᴀᴄᴛɪᴠɪᴛʏ ↜｢ ${time} ｣
┆˼✧˹┊ ᴅᴀʏ ↜｢ ${day} ｣
┆˼⏳˹┊ ᴄʟᴏᴄᴋ ↜｢ ${clock} ｣
╯──────────────⟢

˼⚡˹↜ ᴄᴏᴍᴍᴀɴᴅ ᴘᴀɴᴇʟ ↶ ╮──────────────⟢

${lines.join("\n")}
˼▣˹┊ : ${prefix}
╯──────────────⟢

┊˼⟡˹┊ ${botName} × SHADOW
┊˼✶˹┊ ONLINE ✓`;

    try {
        const stream = await fetchStream(HELP_GIF);
        api.sendMessage({ body: msg, attachment: stream }, event.threadID);
    } catch {
        api.sendMessage(msg, event.threadID);
    }
};
