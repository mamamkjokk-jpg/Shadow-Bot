const path   = require("path");
const fs     = require("fs-extra");
const ytsr   = require("ytsr");

const { downloadVideo, downloadAudio } = require("../lib/dl");

const CACHE = path.join(process.cwd(), "cache");

module.exports.config = {
    name: "ytb",
    version: "2.0.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "تحميل فيديو أو صوت من يوتيوب",
    commandCategory: "ᴍᴇᴅɪᴀ",
    usages: "ytb -a <اسم> | ytb -v <اسم>",
    cooldowns: 5,
    aliases: ["يوتيوب", "yt"]
};

module.exports.run = async function({ api, event, args, pendingSelections }) {
    const tid   = event.threadID;
    const type  = args[0];
    const query = args.slice(1).join(" ").trim();

    if (!["-a", "-v"].includes(type) || !query) {
        return api.sendMessage(
`╭────────────────────⟢
┆ ˼🎬˹ YouTube Downloader
├────────────────────⟢
┆ ytb -a <اسم أو رابط> ← صوت mp3
┆ ytb -v <اسم أو رابط> ← فيديو mp4
╰────────────────────⟢`, tid);
    }

    const dlType = type === "-a" ? "audio" : "video";
    const selKey = `${tid}_${event.senderID}`;

    api.sendMessage("🔍 جاري البحث في يوتيوب...", tid, async (__, loadMsg) => {
        const loadID = loadMsg && loadMsg.messageID;

        try {
            await fs.ensureDir(CACHE);

            let results = [];

            const isUrl = /^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//.test(query);

            if (isUrl) {
                results = [{
                    title: query,
                    url:   query,
                    duration: { seconds: 0, timestamp: "—", toString: () => "—" }
                }];
            } else {
                const searchRes = await ytsr(query, { limit: 8 });
                results = (searchRes.items || [])
                    .filter(i => i.type === "video" && i.url)
                    .slice(0, 6)
                    .map(i => ({
                        title:    i.title    || "—",
                        url:      i.url,
                        duration: i.duration || "—"
                    }));
            }

            if (!results.length) {
                if (loadID) api.unsendMessage(loadID);
                return api.sendMessage("❌ لم يتم العثور على نتائج!", tid);
            }

            if (loadID) api.unsendMessage(loadID);

            if (results.length === 1 || isUrl) {
                const sel = results[0];
                api.setMessageReaction("⏳", event.messageID, () => {}, true);
                const wait = api.sendMessage("⬇️ جاري التحميل...", tid);

                const dl = dlType === "audio" ? downloadAudio : downloadVideo;
                dl(sel.url, (err, filePath) => {
                    if (typeof wait === "function") try { wait(); } catch {}
                    if (err || !filePath) {
                        api.setMessageReaction("❌", event.messageID, () => {}, true);
                        return api.sendMessage("❌ فشل التحميل! جرّب رابطاً آخر.", tid);
                    }
                    api.sendMessage(
                        { body: `✅ ${sel.title}`, attachment: fs.createReadStream(filePath) },
                        tid,
                        (sendErr) => {
                            try { fs.remove(filePath).catch(() => {}); } catch {}
                            if (sendErr) {
                                api.setMessageReaction("❌", event.messageID, () => {}, true);
                                api.sendMessage("❌ فشل الإرسال — الملف كبير جداً!", tid);
                            } else {
                                api.setMessageReaction("✅", event.messageID, () => {}, true);
                            }
                        }
                    );
                });
                return;
            }

            let msg = `╭────────────────────⟢\n┆ ˼🎬˹ نتائج يوتيوب\n├────────────────────⟢\n`;
            for (let i = 0; i < results.length; i++) {
                const dur = results[i].duration || "—";
                msg += `┆ ${i + 1}. ${results[i].title}\n┆    [${dur}]\n`;
            }
            msg += `├────────────────────⟢\n┆ ردّ برقم للتحميل (1-${results.length})\n╰────────────────────⟢`;

            api.sendMessage({ body: msg }, tid, (__, listMsg) => {
                const listID = listMsg && listMsg.messageID;

                pendingSelections.set(selKey, {
                    results: results.map(r => r.url),
                    titles:  results.map(r => r.title),
                    handler: (num, _api, ev) => {
                        if (listID) try { _api.unsendMessage(listID); } catch {}

                        const sel = results[num - 1];
                        if (!sel) return;

                        _api.setMessageReaction("⏳", ev.messageID, () => {}, true);
                        _api.sendMessage("⬇️ جاري التحميل، انتظر...", ev.threadID, (__, dlMsg) => {
                            const dlID = dlMsg && dlMsg.messageID;

                            const dl = dlType === "audio" ? downloadAudio : downloadVideo;
                            dl(sel.url, (err, filePath) => {
                                if (dlID) try { _api.unsendMessage(dlID); } catch {}

                                if (err || !filePath) {
                                    _api.setMessageReaction("❌", ev.messageID, () => {}, true);
                                    return _api.sendMessage("❌ فشل التحميل!", ev.threadID);
                                }

                                _api.sendMessage(
                                    { body: `✅ ${sel.title}`, attachment: fs.createReadStream(filePath) },
                                    ev.threadID,
                                    (sendErr) => {
                                        try { fs.remove(filePath).catch(() => {}); } catch {}
                                        if (sendErr) {
                                            _api.setMessageReaction("❌", ev.messageID, () => {}, true);
                                            _api.sendMessage("❌ الملف كبير، جرّب الجودة الأقل!", ev.threadID);
                                        } else {
                                            _api.setMessageReaction("✅", ev.messageID, () => {}, true);
                                        }
                                    }
                                );
                            });
                        });
                    }
                });

                setTimeout(() => pendingSelections.delete(selKey), 5 * 60 * 1000);
            });

        } catch (e) {
            if (loadID) try { api.unsendMessage(loadID); } catch {}
            console.error("[YTB]", e.message);
            api.sendMessage("❌ خطأ في البحث! حاول مرة أخرى.", tid);
        }
    });
};
