module.exports.config = {
    name: "prefix",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "عرض أو تغيير البادئة",
    commandCategory: "sᴇᴛᴛɪɴɢs",
    usages: "prefix | prefix <بادئة جديدة>",
    cooldowns: 3,
    aliases: []
};

module.exports.run = async function({ api, event, args, config, systemPrefix, threadPrefix, savePrefix }) {
    const newPrefix = args[0] || null;

    if (!newPrefix) {
        const current = threadPrefix || systemPrefix;
        return api.sendMessage(
`🌐 System prefix: ${systemPrefix}
🛸 Your box chat prefix: ${current}`,
            event.threadID
        );
    }

    if (newPrefix.length > 5) {
        return api.sendMessage("❌ البادئة مش تعدى 5 حروف!", event.threadID);
    }

    savePrefix(event.threadID, newPrefix);
    api.sendMessage(
`🌐 System prefix: ${systemPrefix}
🛸 Your box chat prefix: ${newPrefix} ✅`,
        event.threadID
    );
};
