module.exports.config = {
    name: "lock",
    version: "1.2.0",
    hasPermssion: 2,
    credits: "Shadow",
    description: "قفل/فتح البوت (المطور فقط — يشتغل دايماً)",
    commandCategory: "ʙᴏᴛ",
    usages: "lock | unlock",
    cooldowns: 0,
    aliases: ["unlock", "قفل", "فتح"]
};

module.exports.run = async function({ api, event, cmdName, DEVELOPER_ID: DEV_ID, botLocked, setBotLocked }) {
    const tid      = event.threadID;
    const senderID = String(event.senderID || "");

    if (senderID !== String(DEV_ID)) {
        return api.sendMessage("🚫 هذا الأمر للمطور فقط!", tid);
    }

    /* cmdName is passed directly from index.js — 100% reliable */
    const wantsUnlock = ["unlock", "فتح"].includes(cmdName);

    if (wantsUnlock) {
        if (!botLocked) return api.sendMessage("✅ البوت مفتوح بالفعل!", tid);
        setBotLocked(false);
        return api.sendMessage(
`╭────────────────────⟢
┆ ˼🔓˹ تم فتح البوت
├────────────────────⟢
┆ البوت يستقبل الأوامر الآن
┆ في جميع القروبات ✅
╰────────────────────⟢`, tid);
    } else {
        if (botLocked) return api.sendMessage("🔒 البوت مقفل بالفعل!", tid);
        setBotLocked(true);
        return api.sendMessage(
`╭────────────────────⟢
┆ ˼🔒˹ تم قفل البوت
├────────────────────⟢
┆ البوت لا يستقبل إلا
┆ أوامر المطور الآن
╰────────────────────⟢`, tid);
    }
};
