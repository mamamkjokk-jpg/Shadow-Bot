const { exec } = require("child_process");
const axios = require("axios");
const fs    = require("fs-extra");
const path  = require("path");
const os    = require("os");

const YTDLP = "/home/runner/workspace/.pythonlibs/bin/yt-dlp";
const CACHE = path.join(process.cwd(), "cache");

const PLATFORMS = [
    { name: "YouTube",    regex: /youtu\.?be/i },
    { name: "Facebook",   regex: /facebook\.com|fb\.watch/i },
    { name: "Instagram",  regex: /instagram\.com/i },
    { name: "TikTok",     regex: /tiktok\.com|vm\.tiktok\.com/i },
    { name: "Twitter/X",  regex: /twitter\.com|x\.com/i },
    { name: "Snapchat",   regex: /snapchat\.com/i },
    { name: "Pinterest",  regex: /pinterest\.com|pin\.it/i },
    { name: "Reddit",     regex: /reddit\.com|redd\.it/i },
    { name: "Dailymotion",regex: /dailymotion\.com/i },
    { name: "Twitch",     regex: /twitch\.tv/i },
    { name: "Threads",    regex: /threads\.net/i },
    { name: "Vimeo",      regex: /vimeo\.com/i },
    { name: "SoundCloud", regex: /soundcloud\.com/i },
    { name: "Spotify",    regex: /spotify\.com/i },
];

function detectPlatform(url) {
    for (const p of PLATFORMS) if (p.regex.test(url)) return p.name;
    return null;
}

function ytdlpDownload(url, cb) {
    const uid  = `dl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const tmpl = path.join(os.tmpdir(), `${uid}.%(ext)s`);
    const cmd  = `${YTDLP} -o "${tmpl}" --format "bv*[ext=mp4]+ba[ext=m4a]/best[ext=mp4]/best" --merge-output-format mp4 --max-filesize 50m --no-playlist --socket-timeout 30 "${url}" 2>&1`;
    exec(cmd, { timeout: 180000 }, (err, stdout) => {
        if (err) { console.error("[DL]", stdout || err.message); return cb(null); }
        try {
            const files = fs.readdirSync(os.tmpdir()).filter(n => n.startsWith(uid));
            if (!files.length) return cb(null);
            cb(path.join(os.tmpdir(), files[0]));
        } catch { cb(null); }
    });
}

async function apiDownload(url) {
    const apis = [
        `https://api.neokex.online/download?url=${encodeURIComponent(url)}`,
        `https://neokex-dlapis.vercel.app/api/alldl?url=${encodeURIComponent(url)}`,
    ];
    for (const endpoint of apis) {
        try {
            const res = await axios.get(endpoint, { timeout: 15000 });
            const d = res.data;
            const directUrl = d.url || d.video || d.download ||
                (d.video && d.video.downloadUrl) || (d.hd) || (d.sd) ||
                (d.data && d.data.url);
            if (directUrl && typeof directUrl === "string") return directUrl;
        } catch {}
    }
    return null;
}

async function downloadFileFromUrl(fileUrl) {
    const ext      = fileUrl.includes(".mp3") ? "mp3" : "mp4";
    const filePath = path.join(CACHE, `apidl_${Date.now()}.${ext}`);
    await fs.ensureDir(CACHE);
    const res = await axios({ url: fileUrl, method: "GET", responseType: "stream", timeout: 90000 });
    const writer = fs.createWriteStream(filePath);
    res.data.pipe(writer);
    await new Promise((resolve, reject) => {
        writer.on("finish", resolve);
        writer.on("error", reject);
    });
    return filePath;
}

module.exports.config = {
    name: "تحميل",
    version: "3.0.0",
    hasPermssion: 0,
    credits: "Shadow",
    description: "تحميل فيديو من أشهر المنصات",
    commandCategory: "ᴍᴇᴅɪᴀ",
    usages: "تحميل <رابط>",
    cooldowns: 10,
    hidden: false,
    aliases: ["dl", "download"]
};

module.exports.run = async function ({ api, event, args }) {
    const tid = event.threadID;
    const url = (args[0] || "").trim();

    if (!url || !/^https?:\/\//i.test(url)) {
        return api.sendMessage(
`╭────────────────────⟢
┆ ˼📥˹ أمر التحميل
├────────────────────⟢
┆ الاستخدام: تحميل <رابط>
├────────────────────⟢
┆ المنصات المدعومة:
┆ • YouTube  • TikTok
┆ • Facebook • Instagram
┆ • Twitter/X • Snapchat
┆ • Pinterest • Reddit
┆ • Twitch   • Threads
┆ • Vimeo    • Dailymotion
┆ • SoundCloud
╰────────────────────⟢`, tid);
    }

    const platform = detectPlatform(url);
    if (!platform) {
        return api.sendMessage(
`❌ الرابط غير مدعوم!\nالمنصات المدعومة: YouTube, TikTok, Facebook, Instagram, Twitter/X, Snapchat, Pinterest, Reddit, Twitch, Threads, Vimeo, Dailymotion, SoundCloud`, tid);
    }

    api.setMessageReaction("⏳", event.messageID, () => {}, true);
    await fs.ensureDir(CACHE);

    api.sendMessage(`⏳ جاري التحميل من ${platform}...`, tid, async (__, loadMsg) => {
        const loadID = loadMsg && loadMsg.messageID;
        const cleanup = () => { if (loadID) try { api.unsendMessage(loadID); } catch {} };

        let filePath = null;

        try {
            /* Step 1: Try yt-dlp first */
            filePath = await new Promise(resolve => ytdlpDownload(url, resolve));

            /* Step 2: If yt-dlp failed, try API fallback */
            if (!filePath) {
                console.log(`[DL] yt-dlp failed, trying API fallback for ${platform}`);
                const directUrl = await apiDownload(url);
                if (directUrl) {
                    filePath = await downloadFileFromUrl(directUrl).catch(() => null);
                }
            }

            if (!filePath) {
                cleanup();
                api.setMessageReaction("❌", event.messageID, () => {}, true);
                return api.sendMessage(
`❌ فشل التحميل من ${platform}!\n\nتأكد من:\n• أن الرابط صحيح\n• أن الفيديو/المنشور عام (Public)\n• أن الرابط ليس خاصاً أو محمياً`, tid);
            }

            cleanup();
            api.setMessageReaction("📤", event.messageID, () => {}, true);

            api.sendMessage(
                { body: `✅ تم التحميل من ${platform}`, attachment: fs.createReadStream(filePath) },
                tid,
                (sendErr) => {
                    try { fs.unlinkSync(filePath); } catch {}
                    if (sendErr) {
                        api.setMessageReaction("❌", event.messageID, () => {}, true);
                        api.sendMessage("❌ فشل الإرسال! الملف ربما كبير جداً (الحد الأقصى 50MB)", tid);
                    } else {
                        api.setMessageReaction("✅", event.messageID, () => {}, true);
                    }
                }
            );

        } catch (e) {
            console.error("[DL] Unexpected error:", e.message);
            cleanup();
            api.setMessageReaction("❌", event.messageID, () => {}, true);
            api.sendMessage(
`❌ حدث خطأ أثناء التحميل من ${platform}!\nحاول مرة أخرى أو تأكد أن الرابط صحيح وعام.`, tid);
        }
    });
};
