module.exports.config = {
    name: "groups",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Shadow",
    description: "عرض جميع القروبات اللي فيها البوت (مطور فقط)",
    commandCategory: "sʏsᴛᴇᴍ",
    usages: "groups",
    cooldowns: 10,
    aliases: ["قروبات", "grps"]
};

module.exports.run = async function({ api, event, pendingSelections, DEVELOPER_ID }) {
    const tid      = event.threadID;
    const senderID = String(event.senderID || "");

    if (senderID !== String(DEVELOPER_ID)) {
        return api.sendMessage("❌ هذا الأمر للمطور فقط!", tid);
    }

    api.sendMessage("⏳ جاري جلب القروبات...", tid, async (__, loadMsg) => {
        const loadID = loadMsg && loadMsg.messageID;

        try {
            api.getThreadList(100, null, ["INBOX"], (err, threads) => {
                if (err) {
                    if (loadID) api.unsendMessage(loadID);
                    return api.sendMessage("❌ فشل جلب القروبات: " + (err.message || err), tid);
                }

                const groups = (threads || []).filter(t => t.isGroup);

                if (!groups.length) {
                    if (loadID) api.unsendMessage(loadID);
                    return api.sendMessage("❌ البوت مش موجود في أي قروب!", tid);
                }

                let msg = `╭────────────────────⟢\n`;
                msg    += `┆ ˼👥˹ قروبات البوت\n`;
                msg    += `├────────────────────⟢\n`;

                groups.forEach((g, i) => {
                    const name    = g.name || g.threadName || `قروب ${g.threadID}`;
                    const members = (g.participantIDs || []).length;
                    msg += `┆ ${i + 1}. ${name}\n`;
                    msg += `┆    [${members} عضو]\n`;
                });

                msg += `├────────────────────⟢\n`;
                msg += `┆ ردّ برقم للانضمام (1-${groups.length})\n`;
                msg += `╰────────────────────⟢`;

                if (loadID) api.unsendMessage(loadID);

                api.sendMessage(msg, tid, (__, listMsg) => {
                    const listID = listMsg && listMsg.messageID;
                    const selKey = `${tid}_${senderID}`;

                    pendingSelections.set(selKey, {
                        results: groups.map(g => g.threadID),
                        titles:  groups.map(g => g.name || g.threadName || g.threadID),
                        handler: (num, _api, ev) => {
                            if (listID) try { _api.unsendMessage(listID); } catch {}

                            const chosen   = groups[num - 1];
                            if (!chosen) return;

                            const groupName = chosen.name || chosen.threadName || chosen.threadID;
                            const targetID  = String(ev.senderID || "");

                            _api.sendMessage(`⏳ جاري إضافتك في: ${groupName}...`, ev.threadID);

                            _api.addUserToGroup(targetID, chosen.threadID, (addErr) => {
                                if (addErr) {
                                    return _api.sendMessage(
                                        `╭────────────────────⟢\n┆ ˼🔒˹ الإضافة مقفولة\n├────────────────────⟢\n┆ القروب: ${groupName}\n╰────────────────────⟢`,
                                        ev.threadID
                                    );
                                }
                                _api.sendMessage(
                                    `╭────────────────────⟢\n┆ ˼✅˹ تمت الإضافة\n├────────────────────⟢\n┆ القروب: ${groupName}\n╰────────────────────⟢`,
                                    ev.threadID
                                );
                            });
                        }
                    });

                    setTimeout(() => pendingSelections.delete(selKey), 5 * 60 * 1000);
                });
            });

        } catch (e) {
            if (loadID) try { api.unsendMessage(loadID); } catch {}
            console.error("[GROUPS]", e.message);
            api.sendMessage("❌ خطأ غير متوقع!", tid);
        }
    });
};
